"use server";
import { redirect } from "next/navigation";
import { z } from "zod";
import { configured, supabase } from "@/lib/supabase";
import { getConfig } from "@/lib/config";
import {
  isPrivateSignupResult,
  signupEmailAcknowledgement,
} from "@/lib/auth-links";
export async function authAction(_: unknown, form: FormData) {
  if (!configured())
    return {
      error:
        "계정 서비스 연결 준비 중입니다. Supabase 연결 후 가입·로그인을 이용할 수 있습니다.",
    };
  const parsed = z
    .object({
      email: z.email(),
      password: z.string().min(10),
      role: z.enum(["brand", "creator"]),
      name: z.string().min(2).max(80),
      mode: z.enum(["login", "signup"]),
    })
    .safeParse(Object.fromEntries(form));
  if (!parsed.success)
    return { error: "이름, 이메일과 10자 이상의 비밀번호를 확인해주세요." };
  const d = parsed.data;
  const { appOrigin, features } = getConfig();
  if (d.mode === "signup" && features.mail !== "enabled")
    return { error: "가입 메일 서비스 연결을 준비 중입니다." };
  const db = await supabase();
  const result =
    d.mode === "signup"
      ? await db.auth.signUp({
          email: d.email,
          password: d.password,
          options: {
            data: { role: d.role, name: d.name },
            emailRedirectTo: `${appOrigin}/auth/confirm`,
          },
        })
      : await db.auth.signInWithPassword({
          email: d.email,
          password: d.password,
        });
  if (d.mode === "signup" && isPrivateSignupResult(result.error?.code))
    return { message: signupEmailAcknowledgement };
  if (
    result.error &&
    d.mode === "signup" &&
    [
      "email_address_not_authorized",
      "email_address_invalid",
      "over_email_send_rate_limit",
      "unexpected_failure",
    ].includes(result.error.code ?? "")
  )
    return {
      error:
        "인증 메일을 발송하지 못했습니다. 잠시 후 다시 시도하거나 지원 이메일로 문의해주세요.",
    };
  if (result.error)
    return {
      error:
        d.mode === "signup"
          ? "가입을 처리하지 못했습니다. 이메일과 비밀번호를 확인해주세요."
          : "이메일 또는 비밀번호를 확인해주세요.",
    };
  if (d.mode === "signup") {
    if (result.data.session) {
      await db.auth.signOut({ scope: "local" });
      return {
        error: "가입 인증 설정을 확인 중입니다. 운영자에게 문의해주세요.",
      };
    }
    return { message: signupEmailAcknowledgement };
  }
  redirect("/dashboard");
}
export async function logout() {
  const db = await supabase();
  await db.auth.signOut();
  redirect("/");
}
