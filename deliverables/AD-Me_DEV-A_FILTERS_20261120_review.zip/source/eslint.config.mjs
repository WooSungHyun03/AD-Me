import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
export default defineConfig([
  ...nextVitals,
  ...nextTs,
  globalIgnores([
    "dev-a-local/**",
    "supabase/functions/**",
    ".next/**",
    "output/**",
    "playwright-report/**",
    "test-results/**",
  ]),
]);
